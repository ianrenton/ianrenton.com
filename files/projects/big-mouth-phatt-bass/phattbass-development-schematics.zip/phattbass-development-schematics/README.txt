Big Mouth Phatt Bass
Kicad project for schematics used during development

Original work in this project is by Ian Renton and released under the CC Zero licence.

The project also includes the following 3rd party components, used with thanks, and subject to their own licences:
* ESP32-DOIT-Devkit: https://github.com/davidkleymann/doit-esp32-devkit-kicad
* DFR0299: https://www.snapeda.com/parts/DFR0299/DFRobot/view-part/?ref=search&t=DFR0299
* ROB-14450: https://www.snapeda.com/parts/ROB-14450/SparkFun%20Electronics/view-part/?ref=dk&t=ROB-14450&con_ref=None
